﻿namespace lab2.Models
{
    public class Course
    {
        public string Code { get; set; }
        public string Title { get; set; }

    }

}
