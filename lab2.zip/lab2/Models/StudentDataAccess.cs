﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab2.Models
{
    public class CourseDataAccess
    {
        public static List<Course> Courses { get; set; }
        //{
        //    //get
        //    //{
        //    //    return new List<Course> {
        //    //            new Course { Code = "CST8253", Title = "C#"},
        //    //            new Course { Code = "CST8253", Title = "C#"},
        //    //            new Course { Code = "CST8253", Title = "C#"},
        //    //            new Course { Code = "CST8253", Title = "C#"}
        //    //            };
        //    //}
        //}
    }
}
